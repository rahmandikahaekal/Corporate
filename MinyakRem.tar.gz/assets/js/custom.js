$('.carousel').carousel({
  interval: 5000
});

new WOW().init();